<?php

$conexion=mysqli_connect("localhost","root","","login")or die(
    "error de conexion");
?>


<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="menuu.css" rel="stylesheet">
   

    <title>editar</title>
    
</head>
<body>

         
        <div class="container">
            <div class="inicio">
            <h2>Usuarios</h2>
               
            
            <ul>
                <li><a href="nuevomenu.php">Menu</a></li>
                
                <li><a href="index.html">Salir</a></li>
            </ul>
           <div>
       
    
            <div class="espacio">
            <table class="table">
            <thead>
  
                

           </thead>
          <tbody>
    
          <?php
         $id=$_GET['ID'];
         $sql="SELECT * FROM usuario where id='$id'";
         $result = mysqli_query($conexion,$sql);

          while ($mostrar=mysqli_fetch_array($result)){

         ?>
          
         <form action="procesar_editar.php" method="post">
            <input type="hidden" value="<?php  echo $mostrar ['id']?>" name="txtid">
            <p>Nombre</p>
            <input type="text" value="<?php  echo $mostrar ['Nombre']?>" name="txtNombre">
            <p>usuario</p>
            <input type="text" value="<?php  echo $mostrar ['usuario']?>" name="txtusuario">
            <p>contraseña</p>
            <input type="text" value="<?php  echo $mostrar ['contraseña']?>" name="txtcontraseña">
            <p>id_cargo</p>
            <input type="text" value="<?php  echo $mostrar ['id_cargo']?>" name="txtid_cargo">



         
          
    <div>
     <?php
     
   }
     ?>
     <input type="submit" value="Actualizar">
     </form>
 </tbody>
</table>
</body>
</html>