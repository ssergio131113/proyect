<?php

$conexion=mysqli_connect("localhost","root","","login")or die(
    "error de conexion");

    $ID=$_POST['txtId'];
    mysqli_query($conexion,"DELETE FROM usuario where id='$ID'") or die ("error al eliminar");
    mysqli_close($conexion);
    header("location:usuarios.php");
?>
