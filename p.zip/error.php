<?php
    
 echo'<script>alert("ERROR DE AUTENTIFICACION");</script>'
        
 
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0,shrink-to-fit=no">
    <title >Policia Nacional LGTBI</title>
    
    <link rel="stylesheet" href="formulario.css">
</head>
<body>
    
      <div class="contenedor">
          <form action="validar.php"  class="form" method="post">

             <div class="form-header">
    
                 <h1 class="form-title">Policia Nacional LGTBI</h1>
             </div>

       

                  <p class="form-label">Usuario </br><input type="text" placeholder="ingrese su nombre" name="usuario" class="form-input"></p>
                  <p class="form-label">Contraseña </br><input type="password" placeholder="ingrese su contraseña" name="contraseña" class="form-input"></p></br>
                  <input type="submit" class="btn-submit" value="Ingresar"></br>
                  <a class="form-label" href="https://psi.policia.gov.co/PSI/Login.aspx?ReturnUrl=%2fPSI%2f#no-back-button"> olvido su clave</a>

                    
                
                  </div>
            </form> 
    </body>
</html>
