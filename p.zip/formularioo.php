<!DOCTYPE html>
<html lang="es">
  <head>
     <meta charset="UTF-8">
     <meta http-equiv="X-UA-Compatible" content="IE=edge">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>crear caso</title>
     <meta name="viewport" content=" width=device-width, user-scalable=no, initial-scale=1.0, maximum.scale=1.0, minimum-scale=1.0">
     <link rel="stylesheet" href="estiloformulario1.css">
  </head>
  <body>


        <?php
        
         date_default_timezone_set('America/Bogota');
         $Fecha=date('Y-m-d');
         $Hora=date('H:i:s');
        
         ?>

        <div class="contenedor">

            <form  name="formulario"action="insertar.php" class="form" method="post">
                
           
                <div class="form-header">

                  <h1 class="form-title">Crear Caso</h1></br></br>

                  <h2 class="form-title">Localizacion del Caso</h2>

                </div>
               

                <label class="form-label">Fecha<input type="date" name=Fecha class="form-datos" value="<?=$Fecha?>" ></label></input>
                <label class="form-label">Hora<input type="time" name=Hora class="form-datos" value="<?=$Hora?>" ></label></input>

                
                <label class='form-label'>latitud</label></br>
                <input type='text' name='latitud' class="form-input" id='latitud'></br>
                <label class='form-label'>longitud</label></br>
                <input type='text' name='longitud' class="form-input" id='longitud'></br></br>

                <label for="Departamento" class="form-label" >Departamento</label></br>

                <select name="Departamento" id="Departamento" class="form-input">
                        
                </select></br></br>
                
                <label for="Municipio" class="form-label">Municipio</label></br>

                <select name="Municipio" id="Municipio" class="form-input">
                    
                </select><br>

                <label for="Barrio" class="form-label">Barrio</label></br>

                <select name="Barrio" id="Barrio" class="form-input">
                    
                </select><br>

                <label class="form-label">Direccion</label></br>
                <input type="text" name="Direccion" class="form-input" required placeholder="Direccion" autocomplete>
                <br>

                <h2 class="form-title">Datos de la persona</h2>


                <label class="form-label">Nombres</label></br>
                <input type="text" name="Nombres" class="form-input" required placeholder="Nombres" autocomplete>
                <br>
                <label class="form-label">Apellidos</label></br>
                <input type="text" name="Apellidos" class="form-input" required placeholder="Apellidos" autocomplete>
                <br>

                <label for="Tipo" class="form-label">Tipo de Documento de Identidad</label></br>
                <select name="Tipo" class="form-input">
                <option select disabled>Seleccione una Opcion</option>
                <option>T.I</option>
                <option>C.C</option>
                <option>D.E</option>
                <option>C.E</option>
                </select></br></br>

                <label class="form-label">Nro</label></br>
                <input type="text" name="Nro" class="form-input" required placeholder="Nro" autocomplete>
                <br>

                <label class="form-label">Telefono</label></br>
                <input type="text" name="Telefono" class="form-input" required placeholder="Telefono" autocomplete>
                <br>

                <label class="form-label">Email</label></br>
                <input type="email" name=" Email" class="form-input" required placeholder="Email" autocomplete>
                <br>

                <label class="form-label">Direccion</label></br>
                <input type="text" name="Direccion_" class="form-input" required placeholder="Direccion" autocomplete>
                <br>

                <label for="Departamento_" class="form-label" >Departamento</label></br>

                <select name="Departamento_" id="Departamento_" class="form-input">
                        
                </select></br></br>
                
                <label for="Municipio_" class="form-label">Municipio</label></br>

                <select name="Municipio_" id="Municipio_" class="form-input">
                    
                </select><br>

                <label for="Barrio_" class="form-label">Barrio</label></br>

                <select name="Barrio_" id="Barrio_" class="form-input">
                    
                </select><br>
                  
                   

                <h2 class="form-title">Datos de la Accion Realizada por el Funcionario</h2>

                <label for="Informe" class="form-label">Informe</label>
                <textarea name="Informe" class="form-textarea" placeholder="Escriba su informe aqui"></textarea> </br>

                <h2 class="form-title">Datos Funcionario</h2>

                <label class="form-label">Nombres</label></br>
                <input type="text" name="Nombre" class="form-input" required placeholder="Nombres" autocomplete>
                <br>
                <label class="form-label">Apellidos</label></br>
                <input type="text" name="Apellido" class="form-input" required placeholder="Apellidos" autocomplete>
                <br>

                <label class="form-label">C.C</label></br>
                <input type="text" name="CC" class="form-input" required placeholder="Digite su numero de cedula" autocomplete>
                <br>

                
                <label for="Grado"class="form-label">Grado</label></br>
                <select name="Grado" class="form-input">
                <option select disabled>Seleccione una Opcion</option>
                <option>Patrullero</option>
                <option>Subintendente</option>
                <option>Intendente</option>
                </select><br>

                <label class="form-label">Telefono</label></br>
                <input type="text" name="Telefono_" class="form-input" required placeholder="Telefono" autocomplete>
                <br>

                <label class="form-label">Email</label></br>
                <input type="email" name=" Email_" class="form-input" required placeholder="Email" autocomplete>
                <br>

                <label class="form-label">Cuadrante</label></br>
                <input type="text" name=" Cuadrante" class="form-input" required placeholder="Cuadrante" autocomplete>
                <br>

                <label class="form-label">CAI</label></br>
                <input type="text" name=" CAI" class="form-input" required placeholder="CAI" autocomplete>
                <br>

                <label class="form-label">Estacion de policia</label></br>
                <input type="text" name=" Estacion" class="form-input" required placeholder="Estacion de policia" autocomplete>
                <br>

                   
                <input type="file" name="Archivo"  class="form-input" class="for__file">
                 

                <input type="submit"  class="btn-submit" value="Enviar Datos"></br></br>

                <canvas id="canvas" class="none"></canvas>
                </div>
    </div>
         </div>
        </form>
                
        <script src="seleccionar.js"></script>     
 </body>
    
    
</html>
      <script>
        var la=document.getElementById("latitud");
        var lo=document.getElementById("longitud");
         navigator.geolocation.getCurrentPosition(function(position){
          la.setAttribute("value", position.coords.latitude);
          lo.setAttribute("value", position.coords.longitude);
          });

     </script>