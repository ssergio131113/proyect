<?php
$conexion=mysqli_connect('localhost','root','','login') 
or die (mysqli_error($mysqli));


insertar($conexion);
function insertar($conexion){
    $Fecha=$_POST['Fecha'];
    $Hora=$_POST['Hora'];
    $Latitud=$_POST['latitud'];
    $Longitud=$_POST['longitud'];
    $Departamento=$_POST['Departamento'];
    $Municipio=$_POST['Municipio'];
    $Direccion=$_POST['Direccion'];
    $Nombres=$_POST['Nombres'];
    $Apellidos=$_POST['Apellidos'];
    $Tipo=$_POST['Tipo'];
    $Nro=$_POST['Nro'];
    $Telefono=$_POST['Telefono'];
    $Email=$_POST['Email'];
    $Direccion_=$_POST['Direccion_'];
    $Municipio_=$_POST['Municipio_'];
    $Departamento_=$_POST['Departamento_'];
    $Informe=$_POST['Informe'];
    $Nombre=$_POST['Nombre'];
    $Apellido=$_POST['Apellido'];
    $CC=$_POST['CC'];
    $Grado=$_POST['Grado'];
    $Telefono_=$_POST['Telefono_'];
    $Email_=$_POST['Email_'];
    $Cuadrante=$_POST['Cuadrante'];
    $CAI=$_POST['CAI'];
    $Estacion=$_POST['Estacion'];
    $Archivo=$_POST['Archivo'];
    $Barrio=$_POST['Barrio'];
    $Barrio_=$_POST['Barrio_'];
    

$consulta="INSERT INTO casos_creados(Fecha,Hora,latitud,longitud,Departamento,Municipio,Direccion,Nombres,Apellidos,Tipo,Nro,Telefono,Email,Direccion_,municipio_,Departamento_,Informe,Nombre,Apellido,
CC,Grado,Telefono_,Email_,Cuadrante,CAI,Estacion,Archivo,Barrio,Barrio_)
VALUES ('$Fecha','$Hora','$Latitud','$Longitud','$Departamento','$Municipio','$Direccion','$Nombres','$Apellidos','$Tipo','$Nro','$Telefono','$Email','$Direccion_','$Municipio_','$Departamento_',
'$Informe','$Nombre','$Apellido','$CC','$Grado','$Telefono','$Email_','$Cuadrante','$CAI','$Estacion','$Archivo','$Barrio','$Barrio_')";
mysqli_query($conexion,$consulta);
mysqli_close($conexion); 

}
?>
<?php
include("formulario1.php");

?>

 
?>

 
