<?php

$conexion=mysqli_connect("localhost","root","","login")or die(
    "error de conexion");
 $lista="SELECT * FROM casos_creados";
 $reslista=$conexion->query($lista);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>


</head>
<body>
    <header>
        <div class="informacion">
            <h2>Lista de Casos</h2>
         </div>


         <section>
<table class="table">
<tr>
<th>id</th>
<th>Fecha</th>
<th>Hora</th>
<th>Departamento</th>
<th>Municipio</th>
<th>Direccion</th>
</tr>
<?php
while ($listas=$reslista->fetch_array(MYSQLI_BOTH))
{
   
    echo '<tr>
            <td> '.$listas['id']. '</td>
            <td> '.$listas['Fecha']. '</td>
            <td> '.$listas['Hora']. '</td>
            <td> '.$listas['Departamento']. '</td>
            <td> '.$listas['Municipio']. '</td>
            <td> '.$listas['Direccion']. '</td>

         </tr>';
    
}
?>


</table>

         </section>
</header>
</body>
</html>