<?php

$conexion=mysqli_connect("localhost","root","","login")or die(
    "error de conexion");

    $id=$_POST['txtid'];
    $Nombre=$_POST['txtNombre'];
    $usuario=$_POST['txtusuario'];
    $contraseña=$_POST['txtcontraseña'];
    $id_cargo=$_POST['txtid_cargo'];
    
    mysqli_query($conexion,"UPDATE `usuario` SET `Nombre` = '$Nombre ', `usuario` = '$usuario', `contraseña` = '$contraseña', `id_cargo` = '$id_cargo' WHERE `id` = '$id'") 
    or die("error de actualizar");
    mysqli_close($conexion);
    header("location:usuarios.php");
?>