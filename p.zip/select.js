let $Departamento = document.getElementById('Departamento')
let $Municipio = document.getElementById('Municipio')
let $Barrio = document.getElementById('Barrio')


let Departamentos = ['Amazonas', 'Antioquia','Arauca']
let Municipios = ['Leticia', 'El encanto', 'Medellin','Itagui','ditaires']
let Barrios = ['Imperial', 'San Vicente', 'Asia', 'Mala', 'Pacaraos', 'Sumbilca', 'Aucallama', 'Andahua', 'Ayo']

function mostrarLugares(arreglo, lugar) {
    let elementos = '<option selected disables>--Seleccione--</option>'

    for(let i = 0; i < arreglo.length; i++) {
        elementos += '<option value="' + arreglo[i] +'">' + arreglo[i] +'</option>'
    }

    lugar.innerHTML = elementos
}

mostrarLugares(Departamentos, $Departamento,)

function recortar(array, inicio, fin, lugar) {
    let recortar = array.slice(inicio, fin)
    mostrarLugares(recortar, lugar)
}

$Departamento.addEventListener('change', function() {
    let valor = $Departamento.value

    switch(valor) {
        case 'Amazonas':
            recortar(Municipios, 0, 2, $Municipio)
        break
        case 'Antioquia':
            recortar(Municipios, 2, 4, $Municipio)
        break
        case 'Arauca':
            recortar(Municipios, 4, 5, $Municipio)
        break
    }

    $Barrio.innerHTML = ''
})

$Municipio.addEventListener('change', function() {
    let valor = $Municipio.value

    if(valor == 'Leticia') {
        recortar(Barrios, 0, 4, $Barrio)
    } else if(valor == 'El encanto') {
        recortar(Barrios, 4, 7, $Barrio)
    } else {
        recortar(Barrios, 7, 9, $Barrio)
    }
});



let $Departamento_ = document.getElementById('Departamento_')
let $Municipio_ = document.getElementById('Municipio_')
let $Barrio_ = document.getElementById('Barrio_')

let Departamentos_ = ['Lima', 'Arequipa']
let Municipios_ = ['Cañete', 'Huaral', 'Castilla']
let Barrios_ = ['Imperial', 'San Vicente', 'Asia', 'Mala', 'Pacaraos', 'Sumbilca', 'Aucallama', 'Andahua', 'Ayo']

function mostrar(arreglar, sitio) {
    let elementos_ = '<option selected disables>--Seleccione--</option>'

    for(let i = 0; i < arreglar.length; i++) {
        elementos_ += '<option value="' + arreglar[i] +'">' + arreglar[i] +'</option>'
    }

    sitio.innerHTML = elementos_
}

mostrar(Departamentos_, $Departamento_,)

function recorta(array, inicio, fin, sitio) {
    let recortar = array.slice(inicio, fin)
    mostrar(recortar, sitio)
}

$Departamento_.addEventListener('change', function() {
    let valor = $Departamento_.value

    switch(valor) {
        case 'Lima':
            recorta(Municipios_, 0, 2, $Municipio_)
        break
        case 'Arequipa':
            recorta(Municipios_, 2, 3, $Municipio_)
        break
    }

    $Barrio_.innerHTML = ''
})

$Municipio_.addEventListener('change', function() {
    let valor = $Municipio_.value

    if(valor == 'Cañete') {
        recorta(Barrios_, 0, 4, $Barrio_)
    } else if(valor == 'Huaral') {
        recorta(Barrios_, 4, 7, $Barrio_)
    } else {
        recorta(Barrios_, 7, 9, $Barrio_)
    }
});
