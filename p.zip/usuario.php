<?php

$conexion=mysqli_connect("localhost","root","","login")or die(
    "error de conexion");
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="usuario.css" rel="stylesheet">
   

    <title>Menu</title>
    
</head>
<body>

         <div class="image"></div>
        <div class="container">
            <div class="inicio">
            <h2>Usuarios</h2>
               
            
            <ul>
                <li><a href="nuevomenu.php">Menu</a></li>
                
                <li><a href="index.html">Salir</a></li>
            </ul>
           <div>
       
    
            <div class="espacio">
            <table class="table">
            <thead>
  
                    <tr>
                      <th scope="col">id</th>
                      <th scope="col">Nombre</th>
                      <th scope="col">usuario</th>
                      <th scope="col">contraseña</th>
                      <th scope="col">id_cargo</th>
                      <th scope="col">Acciones</th>
                      <th scope="col">Acciones</th>
      
                    </tr>

           </thead>
          <tbody>
    
          <?php
         $sql="SELECT * FROM usuario";
         $result = mysqli_query($conexion,$sql);

          while ($mostrar=mysqli_fetch_array($result)){

         ?>
          
          <tr>
           
          <td ><?php echo $mostrar ['id']?></td>
          <td ><?php echo $mostrar ['Nombre']?></td>
          <td ><?php echo $mostrar ['usuario']?></td>
          <td ><?php echo $mostrar ['contraseña']?></td>
          <td ><?php echo $mostrar ['id_cargo']?></td>

          <td >
            
              <a href="editar.php?ID=<?php echo  $mostrar['id'] ?>">Editar</a>

            
          <form action="eliminar.php" method="post">
          <input type="text" value="<?php echo  $mostrar['id']?>" name="txtId" readonly>
          <td><input type="submit" value="eliminar" name="btneliminar"></td>
          </form>
          </td>

          </tr>
          
    <div>
     <?php
     
   }
     ?>

 </tbody>
</table>
</body>
</html>