<?php
$usuario=$_POST['usuario'];
$contraseña=$_POST['contraseña'];
session_start();
$_SESSION['usuario']=$usuario;


$conexion=mysqli_connect("localhost","root","","login");


$consulta="SELECT*FROM usuario  where  usuario='$usuario' and contraseña='$contraseña'";
$resultado=mysqli_query($conexion,$consulta);



$filas=mysqli_fetch_array($resultado);

if($filas['id_cargo']==1){ 
    header("location:nuevomenu.php");
    header("usuario.php");
     header("lista.php");
}else
if($filas['id_cargo']==2){ 
header("location:menu_cliente.php");

}
else{
  
 header('location:error.php');


}

?>



